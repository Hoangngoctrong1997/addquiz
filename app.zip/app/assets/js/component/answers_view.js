var ansMC = [
  '<div class="checkbox">',
    '<label>',
      '<input type="checkbox" name="ans-value">',
      'Checked default',
    '</label>',
  '</div>',
].join("\n");

var ansSC = [
  '<div class="radio">',
    '<label>',
      '<input type="radio" name="ans-value">',
      'Selected default',
    '</label>',
  '</div>',
].join("\n");

var ansQS = [
  '<div class="textfield">',
    '<input type="text" size=5 name="ans-value" class="form-control" placeholder="Số thứ tự">',
  '</div>',
].join("\n");

